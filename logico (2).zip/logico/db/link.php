<?php



    $host = "localhost";
    $un = "root";
    $pwd = "";
    $db = "logico";


    $link = mysqli_connect($host , $un , $pwd , $db) or die ("Connection Error");
    



?>