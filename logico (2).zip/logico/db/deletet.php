<?php 

    include "link.php";

    $id = $_POST['id'];

    $sql = "DELETE FROM trans WHERE t_id = $id ";

    $r = mysqli_query($link , $sql);

    if($r > 0){
        echo "Deleted ";

    }
    else{
        echo "Unable to Delete";
        
    }




?>