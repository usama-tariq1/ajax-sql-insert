
        
        
        
        <div class="rc" data-simplebar>
            <table id="myTable" style="width:100%;" >

            
            <?php

                include "db/link.php";
                $total = 0;
                $balace = 0;
                $sql = "SELECT * FROM trans ORDER BY t_id DESC  ";
                $r = mysqli_query($link , $sql);
                while($row = mysqli_fetch_array($r)){
                    
                    $am = $row['t_amount'];
                    $total = $total + $am;
                    $ty = $row['t_type'];
                    $balace = $balace + ($ty * $am );
                
            
            
            ?>
                <tr><td>


                <div class="r-row">
                    <div class="left">
                        <div class="indicator <?php if($row['t_type'] == 1){ echo "green-bc"; } else{ echo "red-bc"; } ?>" ></div>
                        <div class="info">
                            <div class="name"><?php echo $row['t_name']; ?></div>
                            <div class="type <?php if($row['t_type'] == 1){ echo "txt-green"; } else{ echo "txt-red"; } ?> "  >
                                <?php  
                                    if($row['t_type'] > 0 ){
                                        echo "Income";
                                    }
                                    else{
                                        echo "Expense";
                                    }
                                ?>
                            </div>
                            <div class="date"><?php echo $row['t_date']; ?></div>
                        </div>
                        <div class="amount <?php if($row['t_type'] == 1){ echo "txt-green"; } else{ echo "txt-red"; } ?>" >
                            Rs. <span><?php echo $row['t_amount']; ?></span>
                            <div class="desc">
                                <?php echo $row['t_desc']; ?>
                            </div>
                        </div>
                    </div>
                    <div class="right">
                        <img  onclick="deletet('#<?php echo $row['t_id']; ?>')" src="icons/del-icon.png" class="icon-del"  alt="">
                        <!-- <img src="icons/preloader3.gif" alt=""> -->
                        <form action="" id="<?php echo $row['t_id']; ?>" > <input name="id" type="hidden" value="<?php echo $row['t_id']; ?>" > </form>
                    </div>
                </div>
                </td></tr>

            <?php } ?>
            </table>
        </div>

        <div class="t-m">
            <div class="total"  >Total: <span><?php echo $total; ?></span> </div>
            <div class="balance <?php if($balace > 0 ){echo "txt-green" ;}else if($balace < 0){ echo "txt-red"; } ?> ">Balance: <span><?php echo $balace; ?></span></div>
        </div>

